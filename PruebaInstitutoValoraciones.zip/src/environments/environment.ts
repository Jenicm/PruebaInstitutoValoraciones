// CONEXION A FIREBASE, TANTO A LA BASE DE DATOS COMO AL RESTO DE SUS UTILIDADES.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCnB5KJnoWdWEI1Jn-wb4-qphjFZLF1ZUM",
    authDomain: "pruebainstitutovaloraciones.firebaseapp.com",
    databaseURL: "https://pruebainstitutovaloraciones.firebaseio.com",
    projectId: "pruebainstitutovaloraciones",
    storageBucket: "pruebainstitutovaloraciones.appspot.com",
    messagingSenderId: "472995419015"
  }
};