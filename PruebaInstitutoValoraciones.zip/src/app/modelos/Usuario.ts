export class Usuario {
    nombre: string;
    apellidos: string;
  }